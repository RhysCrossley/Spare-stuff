﻿using UnityEngine;

public class DestroyUnit : MonoBehaviour
{
	public void OnDestroyUnit()
    {
        Destroy(gameObject);
    }
}
